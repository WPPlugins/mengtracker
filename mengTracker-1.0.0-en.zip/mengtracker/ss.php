<?php
require('../../../wp-blog-header.php');
if($_REQUEST['ss'])
{
	if($_REQUEST['excludeme'])
	update_option("ma_excludeme",$_REQUEST['excludeme']);
	if($_REQUEST['language'])
	update_option("ma_language",$_REQUEST['language']);
	if($_REQUEST['ipLookupPage'])
	update_option("ma_ipLookupPage",$_REQUEST['ipLookupPage']);
	$excludeme=get_option("ma_excludeme");
	if(!isset($excludeme)) $excludeme=1;
	$language=get_option("ma_language");
	if(!isset($language)) $language="turkish";
	$ipLookupPage=get_option("ma_ipLookupPage");
	if(!isset($ipLookupPage)) $ipLookupPage="bikbik";
	include(ABSPATH."wp-content/plugins/mengtracker/languages/".$language.".php");
?>
<table width="100%" height="100%" border=0 cellspacing=0 cellpadding=7>
<tr height="20">
	<td colspan=2 class='settingshead'><?php echo $lang['settings'];?></td>
</tr>
<tr valign="middle"><td align=center><?php echo $lang['settingssaved'];?><br><br><input type="button" name="s" value="<?php echo $lang['ok'];?>" onclick="opensettings();window.location.reload();"></td></tr>

</table>
<?php
}
?>