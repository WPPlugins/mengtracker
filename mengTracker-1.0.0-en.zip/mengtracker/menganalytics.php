<?php
/*
Plugin Name: MengTracker
Plugin URI: http://keditasmasi.com/mengtracker-for-wordpress
Description: MengTracker, is a click tracking & analyzing system for wordpress.
Author: menguzar
Version: 1.0.1b
Author URI: http://www.keditasmasi.com
License: GPL
*/

function mconcat($txt,$lim)
{
	if(strlen($txt)>$lim)
	$txt=substr($txt,0,$lim);
	return $txt;
}

if ( ! class_exists( 'MA_Admin' ) ) {

	class MA_Admin {


		function MA_install() {
			global $wpdb;
			$wpdb->query("CREATE TABLE IF NOT EXISTS `meng_tracker_clicks` (
				  `id` int(11) NOT NULL auto_increment,
				  `longIP` varchar(30) NOT NULL default '',
				  `IP` int(11) default NULL,
				  `clickHost` varchar(255) NOT NULL default '',
				  `clickURL` varchar(255) NOT NULL default '',
				  `outbound` int(11) default NULL,
				  `clickType` varchar(30) default NULL,
				  `clickPage` varchar(255) default NULL,
				  `clickDate` datetime default NULL,
				  PRIMARY KEY  (`id`)
				)");
				add_option("ma_excludeme",1);
				add_option("ma_ipLookupPage", "http://www.dnsstuff.com/tools/whois.ch?ip=");
				add_option("ma_language","english");

		}

		function add_config_page() {
			global $wpdb;
			if ( function_exists('add_submenu_page') ) {
				add_submenu_page('link-manager.php', 'MengTracker', 'MengTracker', 1, basename(__FILE__), array('MA_Admin','config_page'));
			}
		}

		function config_page() {
			global $uastring,$wpdb,$_REQUEST;
			$excludeme=get_option("ma_excludeme");
			$language=get_option("ma_language");
			$ipLookupPage=get_option("ma_ipLookupPage");
			include(ABSPATH."wp-content/plugins/mengtracker/languages/".$language.".php");
			include("ma_admin.php");
		}

	}

}

if ( ! class_exists( 'MA_Filter' ) ) {
	class MA_Filter {


		function ma_get_domain($uri){

			$hostPattern = "/^(http:\/\/)?([^\/]+)/i";
			$domainPattern = "/[^\.\/]+\.[^\.\/]+$/";
			$or=parse_url(get_option('site_url'));
			$origin=$or['host'];
			preg_match($hostPattern, $uri, $matches);
			$host = $matches[2];
			preg_match($domainPattern, $host, $matches);
			return array("domain"=>$matches[0],"host"=>$host);

		}


		function ma_parse_link($leaf, $matches){
			global $origin,$excludeme;
			$excludeme=get_option("ma_excludeme");

			$target = MA_Filter::ma_get_domain($matches[3]);
			$coolbit = "";
			if ( ($excludeme && ($target["domain"] != $origin["domain"])) || !$excludeme  ){
				$coolBit .= "onmouseup=\"javascript:mengTracker('".$leaf."',this.href,1);\"";
			}
			return '<a href="' . $matches[2] . '//' . $matches[3] . '" ' . $matches[1] . $matches[4] . ' '.$coolBit.'>' . $matches[5] . '</a>';
		}

		function ma_parse_article_link($matches){
			return MA_Filter::ma_parse_link("post",$matches);
		}

		function ma_parse_comment_link($matches){
			return MA_Filter::ma_parse_link("comment",$matches);
		}
		function ma_parse_cats_link($matches){
			return MA_Filter::ma_parse_link("categories_list",$matches);
		}
		function ma_parse_pages_link($matches){
			return MA_Filter::ma_parse_link("pages_list",$matches);
		}
		function ma_parse_category_link($matches){
					return MA_Filter::ma_parse_link("post_category",$matches);
		}
		function list_cats($text) {
			static $anchorPattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
			$text = preg_replace_callback($anchorPattern,array('MA_Filter','ma_parse_cats_link'),$text);
			return $text;
		}
		function list_pages($text) {
			static $anchorPattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
			$text = preg_replace_callback($anchorPattern,array('MA_Filter','ma_parse_pages_link'),$text);
			return $text;
		}
		function the_content($text) {
			static $anchorPattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
			$text = preg_replace_callback($anchorPattern,array('MA_Filter','ma_parse_article_link'),$text);
			return $text;
		}
		function the_category($text) {
			static $anchorPattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
			$text = preg_replace_callback($anchorPattern,array('MA_Filter','ma_parse_category_link'),$text);
			return $text;
		}
		function comment_text($text) {
			static $anchorPattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
			$text = preg_replace_callback($anchorPattern,array('MA_Filter','ma_parse_comment_link'),$text);
			return $text;
		}

		function comment_author_link($text) {
			global $origin,$excludeme;
			$excludeme=get_option("ma_excludeme");
			static $anchorPattern = '(.*href\s*=\s*)[\"\']*(.*)[\"\'] (.*)';
			ereg($anchorPattern, $text, $matches);
			if ($matches[2] == "") return $text;

			$target = MA_Filter::ma_get_domain($matches[2]);
			$coolbit = "";
			$origin = MA_Filter::ma_get_domain($_SERVER["HTTP_HOST"]);
			if ( ($excludeme && ($target["domain"] != $origin["domain"])) || !$excludeme  ){
				$coolBit .= " onmouseup=\"javascript:mengTracker('commentauthor',this.href);\" ";
			}
			return $matches[1] . "\"" . $matches[2] . "\"" . $coolBit . $matches[3];
		}

		function ma_addheader()
		{
			echo "<script src=\"".get_option("siteurl")."/wp-content/plugins/mengtracker/mengTrack.js\" type=\"text/javascript\"></script>";

		}
	}
}

$version = "0.0.1";

$gaf = new MA_Filter();
add_action('init', array('MA_Admin','MA_install'));
add_action('admin_menu', array('MA_Admin','add_config_page'));

add_action('wp_footer', array('MA_Filter','ma_addheader'));

add_filter('list_cats', array('MA_Filter','list_cats'), 99);
add_filter('the_content', array('MA_Filter','the_content'), 99);
add_filter('wp_list_pages', array('MA_Filter','list_pages'), 99);
add_filter('the_category', array('MA_Filter','the_category'), 99);
add_filter('the_excerpt', array('MA_Filter','the_content'), 99);
add_filter('comment_text', array('MA_Filter','comment_text'), 99);
add_filter('get_comment_author_link', array('MA_Filter','comment_author_link'), 99);

?>