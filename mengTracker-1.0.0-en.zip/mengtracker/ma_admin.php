<style type="text/css">
.resultpane{
	height:150px;
	width:590px;
	margin: 0px auto 0px auto;
}
.lastclickspane{
	width:97%;
	margin: 0px auto 0px auto;
}
.resulttitle {
	font-size:15px;
	color: #10558C;
	margin:7px;
	font-weight:bold;
}
td {
	font-size:11px;
}
#settingsoverlay {
	width:100%;
	height:100%;
	filter:alpha(opacity=50);-moz-opacity:.50;opacity:.50;
	background-color: #505050;
	z-index:99;
	display:none;
	position:absolute;
	vertical-align:center;
}
#settings {
	display:none;
	position:absolute;
	width:450px;
	height:200px;
	background-color:#ffffff;
	border: 2px solid #7cc3ff;
	filter:alpha(opacity=100);-moz-opacity:1;opacity:1;z-index:100;
}
.settingshead {
	background-color : #7cc3ff;
	color: #10558C;
	text-align:center;
	font-size:14px;
	font-weight:bold;
}
.settingsrow {
	padding:4px;
}
.settingsrowl {
	width:120px;
	padding:4px;
}
#contentdiv{

	width:100%;
	height:435px;
	overflow:auto;
	background-color:  #6BA6D6;
	border-top: 10px solid #6BA6D6;
	border-right: 1px solid #cfcfcf;
	border-bottom: 10px solid #6BA6D6;
}
.resultbutton {
	width:100%;
	height:30;
	font-size:11px;
	padding:4px;
	margin-bottom:3px;
	cursor:pointer;
	background-color: #cfcfcf;
	border-top: 1px solid #cfcfcf;
	border-left: 1px solid #cfcfcf;
	border-bottom: 1px solid #cfcfcf;
	color:#10558C;
	font-weight:bold;
}
.chart{
margin:0px 10px 10px 10px;
}
.resultfilter {
	width:100%;
	height: 296px;
	font-size:11px;
	padding:4px;
	color: #C6DFF7;
	margin-top:0px;
	background-color: #10558C;
	border-top: 1px solid #cfcfcf;
	border-left: 1px solid #cfcfcf;
	border-bottom: 10px solid #6BA6D6;
}
.filterlink,.filterlink:visited {
	color: #C6DFF7;
	text-decoration:none;
}
.filterlink:hover {
	color: white;
	text-decoration:none;
}
.setselect {
	width: 150px;
	font-size:11px;
	height:20px;
	padding:2px;
}
#lastclicksdiv {
	height: 444px;
	overflow: auto;
}
.link {
	cursor:pointer;
}
.alert {
	width:450px;
	margin-left:auto;
	margin-right:auto;
	height:50px;
	border: 1px solid #cfcfcf;
	background-color: #10558C;
	color: #C6DFF7;
	font-size:17px;
	text-align:center;
	padding-top: 25px;

}
</style>
<script language="javascript" type="text/javascript" src="<?php bloginfo('wpurl'); ?>/wp-content/plugins/mengtracker/moo.js"></script>
<script language="javascript" type="text/javascript">
var settingsOpen=0;
var divOpen=0;
function opensettings()
{
	if(!settingsOpen)
	{
		document.getElementById('settingsoverlay').style.display='block';
		var settings=document.getElementById('settings')
		settings.style.display='block';
		settings.style.left=(screen.width/2-150)+'px';
		settings.style.top=(screen.height/2-250)+'px';
		settingsOpen=1;
	}
	else
	{
		document.getElementById('settingsoverlay').style.display='none';
		document.getElementById('settings').style.display='none';
		settingsOpen=0;
	}

}
function savesettings()
{
	var f=$('frmsettings');
	if(f.excludeme.checked) checked=1; else checked=0;
	var url="<?php echo get_option("siteurl")?>/wp-content/plugins/mengtracker/ss.php?ss=1&language="+f.language.options[f.language.selectedIndex].value+"&excludeme="+checked+"&ipLookupPage="+encodeURIComponent(f.ipLookupPage.value);
	var contentAjax= new Ajax(url, {update: 'settings'}).request();

}

function opendiv(d)
{
	if(!d)
	d=divOpen;
	if(!divOpen)
	d="lastclicks";
	//chartlarla bi arada olmuyo
	if(d!="lastclicks")
	{
		$('settinglink').style.display='none';
	}
	else
	{
		$('settinglink').style.display='inline';

	}
	var f=$('frmselect');
	var interval=f.interval.options[f.interval.selectedIndex].value;
	var clickType=f.clickType.options[f.clickType.selectedIndex].value;
	var limit=f.limit.options[f.limit.selectedIndex].value;
	var clickHost=f.clickHost.value;
	var clickURL=f.clickURL.value;
	$(d+"res").style.backgroundColor='#6BA6D6';
	if(divOpen && divOpen!=d)
	{
		$(divOpen+"res").style.backgroundColor='#cfcfcf';
	}
	$('frmselect').divOpen.value=d;
	divOpen=d;
	var url="<?php echo get_option("siteurl")?>/wp-content/plugins/mengtracker/content.php?clickHost="+clickHost+"&clickURL="+clickURL+"&page=menganalytics.php&divOpen="+d+"&interval="+interval+"&clickType="+clickType+"&limit="+limit;
	var contentAjax2= new Ajax(url, {method: 'get',update: 'contentdiv',evalScripts:true}).request();


}
function resethost()
{
	var f=$('frmselect');
	f.clickHost.value='';
	f.clickURL.value='';
	opendiv();
}
function resetall()
{
	var f=$('frmselect');
	f.clickHost.value='';
	f.clickURL.value='';
	f.interval.selectedIndex=0;
	f.clickType.selectedIndex=0;
	f.limit.selectedIndex=0;
	opendiv("lastclicks");
}
</script>

<div id="settingsoverlay">
</div>
<div id="settings">
	<table width="100%" border=0 cellspacing=0 cellpadding=7>
	<tr>
		<td colspan=2 class='settingshead'><?php echo $lang['settings'];?></td>
	</tr>
	<tr>
		<td colspan=2> </td>
	</tr>
	<form name="frmsettings" id="frmsettings">
	<tr>
		<td class='settingsrowl'><?php echo $lang['language'];?></td>
		<td class='settingsrow'><select name="language">
		<?php
			$dir=ABSPATH."wp-content/plugins/mengtracker/languages/";
			$d = dir($dir);
			while (false !== ($entry = $d->read())) {
				if($entry!="." && $entry!="..")
				{
					$entry=str_replace(".php","",$entry);
					echo "<option ";
					if($entry==$language) echo "selected";
					echo " >".$entry."</option>";
				}
			}
			?></select>
		</td>
	</tr>
	<tr>
		<td class='settingsrowl'><?php echo $lang['iplookup'];?></td>
		<td class='settingsrow'><input style="width:95%;" name="ipLookupPage" value="<?php echo $ipLookupPage;?>"></td>
	</tr>
	<tr>
		<td class='settingsrowl'><?php echo $lang['excludeme'];?></td>
		<td class='settingsrow'><input type=checkbox name="excludeme" value="1" <?php if($excludeme) echo "checked";?>></td>
	</tr>
	<tr>
		<td colspan=2 align=center><input type="button" name="s" value="<?php echo $lang['savesettings'];?>" onclick="savesettings();"><input type="button" name="s" value="<?php echo $lang['cancel'];?>" onclick="opensettings();"></td>
	</tr>
	</form>
	</table>
</div>
<div class="wrap">
	<h2>MengTracker</h2>


	<table border=0 cellspacing=0 cellpadding=0 width="100%" align=center>

	<tr valign="top">
		<td width="160">
			<?php if(!$_REQUEST['clickHost']&&!$_REQUEST['clickURL']){?>
			<div class="resultbutton" id="mostpopularsitesres" onclick="opendiv('mostpopularsites');"><?php echo $lang['sites'];?></div>
			<div class="resultbutton" id="mostpopularpagesres" onclick="opendiv('mostpopularpages');"><?php echo $lang['pages'];?></div>
			<?php }  if(!$_REQUEST['clickType']){?>
			<div class="resultbutton" id="mostclickedregionsres" onclick="opendiv('mostclickedregions');"><?php echo $lang['clickregions'];?></div>
			<?php }?>
			<div class="resultbutton" id="mostclickedpagesres" onclick="opendiv('mostclickedpages');"><?php echo $lang['clickpages'];?></div>
			<div class="resultbutton" id="lastclicksres" onclick="opendiv('lastclicks');"><?php echo $lang['lastclicks'];?></div><div class="resultfilter">
			<b><?php echo $lang['filter'];?></b><br><br>
			<form id="frmselect" name="frmselect" action="link-manager.php" method="get">

			<input type="hidden" name="clickHost" value="<?php echo $_GET['clickHost'];?>">
			<input type="hidden" name="clickURL" value="<?php echo $_GET['clickURL'];?>">
			<input type="hidden" name="page" value="menganalytics.php">
			<input type="hidden" name="divOpen" value="">
			<select class="setselect" name="interval" onchange="opendiv();">
				<option value="today" <?php if($interval=="today") echo "selected";?>><?php echo $lang['today'];?></option>
				<option value="yesterday" <?php if($interval=="yesterday") echo "selected";?>><?php echo $lang['yesterday'];?></option>
				<option value="last7" <?php if($interval=="last7") echo "selected";?>><?php echo $lang['last7'];?></option>
				<option value="priorlast7" <?php if($interval=="priorlast7") echo "selected";?>><?php echo $lang['priorlast7'];?></option>
				<option value="thismonth" <?php if($interval=="thismonth") echo "selected";?>><?php echo $lang['thismonth'];?></option>
				<option value="lastmonth" <?php if($interval=="lastmonth") echo "selected";?>><?php echo $lang['lastmonth'];?></option>
				<option value="thisyear" <?php if($interval=="thisyear") echo "selected";?>><?php echo $lang['thisyear'];?></option>
				<option value="alltimes" <?php if($interval=="alltimes") echo "selected";?>><?php echo $lang['alltimes'];?></option>
			</select><br />

			<select class="setselect" name="clickType" onchange="opendiv();">
				<option value=""><?php echo $lang['allregions'];?></option>
				<?php
				$cts=$wpdb->get_results("select distinct clickType as ct from meng_tracker_clicks order by clickType");
				foreach($cts as $ct)
				{
					if($ct->ct)
					{
						echo "<option";
						if($ct->ct==$_GET["clickType"])
						{
							echo " selected";
						}
						echo ">".$ct->ct."</option>";
					}
				}?>
			</select><br />
			<select class="setselect" name="limit" onchange="opendiv();">
				<option value="10" <?php if($limit=="10") echo "selected";?>><?php echo $lang['first10'];?></option>
				<option value="50" <?php if($limit=="50") echo "selected";?>><?php echo $lang['first50'];?></option>
				<option value="100" <?php if($limit=="100") echo "selected";?>><?php echo $lang['first100'];?></option>
				<option value="all" <?php if($limit=="all") echo "selected";?>><?php echo $lang['all'];?></option>
			</select>
			</form>
			<br><br>

			<div align="center"><span id="settinglink"><a class="filterlink" href="#" onclick="opensettings();"><?php echo $lang['settingsmenu'];?></a> | </span><a class="filterlink"  href="#" onclick="opendiv();"><?php echo $lang['refresh'];?></a></div>
		</div>
		</td>
		<td width=620>
			<div id="contentdiv" ></div>
		</td>
	</tr>
</table>
</div>
<script><?php if($_REQUEST['clickHost']&&$_REQUEST['clickURL']){?>
opendiv('mostclickedregions');
<?php }
else {
	if($_REQUEST['divOpen']){?>
		opendiv('<?php echo $_REQUEST['divOpen'];?>');
	<?php }
	else {?>
		opendiv('lastclicks');
<?php }
}?>
</script>