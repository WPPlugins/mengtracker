<?php
require('../../../wp-blog-header.php');
$excludeme=get_option("ma_excludeme");
$language=get_option("ma_language");
$ipLookupPage=get_option("ma_ipLookupPage");
include(ABSPATH."wp-content/plugins/mengtracker/languages/".$language.".php");
function putchart($id)
{
?>
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="590" height="240" id="am_pie" align="middle">
			<param name="allowScriptAccess" value="sameDomain" />
			<param name="movie" value="<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/ampie.swf?ampie_settingsFile=<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/setchart<?php echo $id;?>.txt&ampie_path=<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/"/>
			<param name="play" value="false" />
			<param name="loop" value="false" />
			<param name="menu" value="false" />
			<param name="quality" value="high" />
			<param name="scale" value="noscale" />
			<param name="salign" value="lt" />
			<param name="bgcolor" value="#FFFFFF" />
			<embed src="<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/ampie.swf?ampie_settingsFile=<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/setchart<?php echo $id;?>.txt&ampie_path=<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/mengtracker/ampie/" play="false" loop="false" menu="false" scale="noscale" quality="high" salign="lt" bgcolor="#FFFFFF" width="590" height="240" name="am_pie" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
			</object>

<?php

}
/*hacks*/
$order="c";
$asc="DESC";
$showl=30;

$wheres="";
$wheret="";
if($_GET["interval"]=="")
$interval="today";
else
$interval=$_GET["interval"];

//BUILDING SQL...

//set the interval
switch($interval)
{
	case "today":
		$wheret.=" (TO_DAYS(now())- TO_DAYS(clickDate) = 0)";
	break;
	case "yesterday":
		$wheret.=" (TO_DAYS(now())- TO_DAYS(clickDate) = 1)";
	break;
	case "last7":
		$wheret.=" (TO_DAYS(now())- TO_DAYS(clickDate) <7)";
	break;
	case "priorlast7":
		$wheret.=" (TO_DAYS(now())- TO_DAYS(clickDate) >6) AND (TO_DAYS(now())- TO_DAYS(clickDate) <14)";
	break;
	case "thismonth":
		$wheret.=" MONTH(now()) = MONTH(clickDate)";
	break;
	case "lastmonth":
		$wheret.=" DATE_SUB(CURDATE(),INTERVAL 60 DAY) <= clickDate AND DATE_SUB(CURDATE(),INTERVAL 30 DAY) > clickDate";
	break;
	case "thisyear":
		$wheret.=" YEAR(now())=YEAR(clickDate)";
	break;
	case "alltimes":
		$wheret="";
	break;
}

//set the region
if($_GET["clickType"])
{
	if($wheres||$wheret)
	$wheres.=" AND ";
	$wheres.=" clickType='".$_GET["clickType"]."' ";

}

//set the host
if($_GET["clickHost"])
{
	if($wheres||$wheret)
	$wheres.=" AND ";
	$wheres.=" clickHost='".$_GET["clickHost"]."' ";
}

//set the url
if($_GET["clickURL"])
{
	if($wheres||$wheret)
	$wheres.=" AND ";
	$wheres.=" clickURL='".$_GET["clickURL"]."' ";
}

//exlclude yourself
if ($wheres!=""||$wheret){
	$where=" WHERE $wheret $wheres ";
	if($excludeme)
	$ch=" AND clickHost!='www.keditasmasi.com'";
}
else
{
	if($excludeme)
	$ch="WHERE clickHost!='www.keditasmasi.com' ";
}

//trim the sql if necessary
if(substr($wheres,4,strlen($wheres))!="")
{	if($wheret)
	$wherelc=" WHERE ".substr($wheres,4,strlen($wheres))." AND ".$wheret;
	else
	$wherelc=" WHERE ".$wheres;

}

//limit
if(!$_GET["limit"])
$limit="20";
else
$limit=$_GET["limit"];

if($limit=="all")
$limits="";
else
$limits=" LIMIT $limit";

//run the queries
?>

	<h3 style="font-family:Tahoma;font-size:14px; " align=center>
		<?php
		if($_GET["clickType"])
			echo $_GET["clickType"]."   ".$lang['clicksfrom'];

		if($_GET["clickHost"]||$_GET["clickURL"])
			echo $_GET["clickHost"].$_GET["clickURL"]." ".$lang['clicksgoingto'];
		if ($_GET["clickType"]||$_GET["clickHost"]||$_GET["clickURL"])
		echo " <br>[<a class='link' onclick='resethost();'>".$lang['goback']."</a>][<a class='link' onclick=\"resetall();\">".$lang['reset']."</a>]";
		?>
	</h3>
<?php
switch($_REQUEST['divOpen'])
{
	case "mostpopularsites":
		$hosts=$wpdb->get_results("select count(*) as c, clickHost from meng_tracker_clicks $where $ch group by clickHost order by $order $asc $limits");
		if($wpdb->num_rows)
		{
			?>
			<center><div class="resulttitle"><?php echo $lang['mostpopularsites'];?></div></center>
			<?php
			$fp=fopen(ABSPATH."wp-content/plugins/mengtracker/ampie/chart1.txt","w");
			foreach($hosts as $link)
			{
				if(trim($link->clickHost))
				fputs($fp,$link->clickHost.";".$link->c."\n");
			}
			fclose($fp);
			?>
			<div class="chart" align=center>
				<?php putchart(1);?>
			</div>



			<div class="resultpane" align=center>
				<table border=0 cellspacing=2 cellpadding=3 width="100%" align=center bgcolor="#efefef">

				<tr>
					<th><?php echo $lang['site'];?></th>
					<th><?php echo $lang['click'];?></th>
				</tr>
				<?php
				$toka=0;
				if($hosts)
				{
					foreach($hosts as $link)
					{
						if(trim($link->clickHost))
						{
							$toka++;
							$toka%2?$bg="class='alternate'":$bg="";
							echo "<tr $bg>";
							echo "	<td><a href='http://".$link->clickHost."'>".$link->clickHost."</a></td>";
							echo "	<td>".$link->c."</td>";
							echo "</tr>";
						}
					}
				}
				?>
				</table>
			<?}
			else
			{?><div class="alert" align="center" ><?php echo $lang['notenoughdata'];?></div><?php }?>
		</div>
		<?php
	break;
	case "mostpopularpages":
		$links=$wpdb->get_results("select count(*) as c, clickHost,clickURL from meng_tracker_clicks $where group by clickHost,clickURL order by $order $asc $limits");
		if($wpdb->num_rows){
		?>
		<center><div class="resulttitle"><?php echo $lang['mostpopularpages'];?></div></center>
			<?php
			$fp=fopen(ABSPATH."wp-content/plugins/mengtracker/ampie/chart2.txt","w");
			foreach($links as $link)
			{
				if(trim($link->clickHost))
				fputs($fp,$link->clickHost.$link->clickURL.";".$link->c."\n");
			}
			fclose($fp);
			?>
			<div class="chart" align=center>
			<?php putchart(2);?>
			</div>
			<div class="resultpane">
			<table border=0 cellspacing=2 cellpadding=3 width="100%" align=center bgcolor="#efefef">						<tr>
				<th>Link</th>
				<th><?php echo $lang['click'];?></th>
			</tr><?php
			$toka=0;
			if($links)
			{
				foreach($links  as $link)
				{
					if(trim($link->clickHost))
					{
						$toka++;
						$toka%2?$bg="class='alternate'":$bg="";
						echo "<tr $bg>";
						echo "	<td><a href='http://".$link->clickHost.$link->clickURL."'>".mconcat($link->clickHost.$link->clickURL,$showl)."</a></td>";
						echo "	<td>".$link->c."</td>";
						echo "</tr>";
					}
				}
			}
			?>
			</table>
			<?}
						else
			{?><div class="alert" align="center" ><?php echo $lang['notenoughdata'];?></div><?php }?>
		</div>

		<?php
	break;
	case "mostclickedregions":
		$clickPlaces=$wpdb->get_results("select count(*) as c, clickType from meng_tracker_clicks $where group by clickType order by $order $asc $limits");

		if($wpdb->num_rows)

		{
		?>
			<center><div class="resulttitle"><?php echo $lang['mostclickedregions'];?></div></center>
				<?php
				$fp=fopen(ABSPATH."wp-content/plugins/mengtracker/ampie/chart3.txt","w");
				foreach($clickPlaces as $link)
				{
					if(trim($link->clickType))
					fputs($fp,$link->clickType.";".$link->c."\n");
				}
				fclose($fp);
				?>
				<div class="chart" align=center>
					<?php putchart(3);?></div>

			<div class="resultpane">
				<table border=0 cellspacing=2 cellpadding=3 width="100%" align=center bgcolor="#efefef">						<tr>
					<th><?php echo $lang['region'];?></th>
					<th><?php echo $lang['click'];?></th>
				</tr><?php
				$toka=0;
				if($clickPlaces)
				{
					foreach($clickPlaces as $link)
					{
						if(trim($link->clickType))
						{
							$toka++;
							$toka%2?$bg="class='alternate'":$bg="";
							echo "<tr $bg>";
							echo "	<td><a href='#' onclick=\"frmselect.divOpen.value='0';frmselect.clickType.value='".$link->clickType."';opendiv('mostclickedpages');\">".$link->clickType."</a></td>";
							echo "	<td>".$link->c."</td>";
							echo "</tr>";
						}
					}
				}
				?></table>
				<?}
							else
			{?><div class="alert" align="center" ><?php echo $lang['notenoughdata'];?></div><?php }?>
			</div>
		<?php
	break;
	case "mostclickedpages":
		$clickPages=$wpdb->get_results("select count(*) as c, clickPage from meng_tracker_clicks $where group by clickPage order by $order $asc $limits");
		if($wpdb->num_rows)
		{
		?>
		<center><div class="resulttitle"><?php echo $lang['mostclickedpages'];?></div></center>
		<?php
		$fp=fopen(ABSPATH."wp-content/plugins/mengtracker/ampie/chart4.txt","w");
		foreach($clickPages as $link)
		{
			if(trim($link->clickPage))
			fputs($fp,$link->clickPage.";".$link->c."\n");
		}
		fclose($fp);
		?>
		<div class="chart" align=center>
		<?php putchart(4);?></div>

		<div class="resultpane">
		<table border=0 cellspacing=2 cellpadding=3 width="100%" align=center bgcolor="#efefef">						<tr>
			<th><?php echo $lang['page'];?></th>
			<th><?php echo $lang['click'];?></th>
		</tr><?php
		$toka=0;
		if($clickPages)
		{
			foreach($clickPages as $link)
			{
				if(trim($link->clickPage))
				{
					$toka++;
					$toka%2?$bg="class='alternate'":$bg="";
					echo "<tr $bg>";
					echo "	<td><a target=\"_blank\" href='".$link->clickPage."'>".mconcat($link->clickPage,$showl)."</a></td>";
					echo "	<td>".$link->c."</td>";
					echo "</tr>";
				}
			}
		}
		?></table>
		<?}
					else
			{?><div class="alert" align="center" ><?php echo $lang['notenoughdata'];?></div><?php }?>
		</div>
		<?php
	break;
	case "lastclicks":
		$lastclicks=$wpdb->get_results("select clickHost,clickURL,clickType,clickPage,longIP,DATE_FORMAT(clickDate,'%d.%m %H:%i:%S') as clickDate2 from meng_tracker_clicks $where order by clickDate desc $limits");
		if($wpdb->num_rows)
		{
		?>
		<center><div class="resulttitle"><?php echo $lang['lastclicks'];?></div></center>

		<div class="lastclickspane">
		<table border=0 cellspacing=2 cellpadding=3 width=100% bgcolor="#efefef">
			<tr>
			<th><?php echo $lang['site'];?></th>
			<th><?php echo $lang['page'];?></th>
			<th><?php echo $lang['region'];?></th>
			<th>IP</th>
			<th><?php echo $lang['time'];?></th>
		</tr>						<?php
		$toka=0;
		if($lastclicks)
		{
			foreach($lastclicks as $link)
			{
				$toka++;
				$toka%2?$bg="class='alternate'":$bg="";
				echo "<tr $bg>";
				echo "	<td><a title='http://".$link->clickHost.$link->clickURL." ".$lang['gotodata']."' href='#' onclick=\"frmselect.clickHost.value='".$link->clickHost."';frmselect.clickURL.value='".$link->clickURL."';opendiv('mostclickedregions');\">".mconcat($link->clickHost.$link->clickURL,$showl)."</a></td>";
				echo "	<td>".mconcat($link->clickPage,$showl)."</td>";
				echo "	<td>".$link->clickType."</td>";
				echo "	<td><a target=\"_blank\" href=\"".$ipLookupPage.$link->longIP."\">".$link->longIP."</a></td>";
				echo "	<td>".$link->clickDate2."</td>";
				echo "</tr>";
			}
		}
		?></table>
		<?}
					else
			{?><div class="alert" align="center" ><?php echo $lang['notenoughdata'];?></div><?php }?>
		</div>
		<?php
	break;



}
?>



