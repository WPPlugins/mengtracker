﻿m_image = new Image;
m_image.onload = m_returntrue;
m_image.onerror = m_returntrue;
function mengTracker(clickedFrom, outboundLink,ob,go,isForm)
{
	var ol=outboundLink.replace("http://","");
	var url="/wp-content/plugins/mengtracker/mengTrack.php?ct="+clickedFrom+"&ol="+encodeURIComponent(ol)+"&o="+ob;
	m_image.src=url;
	if(isForm)
	eval(clickedFrom+".submit();");

}
function m_returntrue () {
    return true;
}

