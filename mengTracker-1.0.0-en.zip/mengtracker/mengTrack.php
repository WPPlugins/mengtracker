<?php
require('../../../wp-blog-header.php');

 function ipcon($ip)
 {
 	$x=explode(".",$ip);
 	return $x[3]+($x[2]*256)+($x[1]*65536)+($x[0]*16777216);
}
$ip=ipcon($_SERVER["REMOTE_ADDR"]);
$longIP=$_SERVER["REMOTE_ADDR"];
$outbound=$_GET["o"];
$clickType=$_GET["ct"];
$ol="";
if(!strstr($_GET["ol"],"http://"))
$ol="http://";
$ol.=$_GET["ol"];
$click=parse_url($ol);
$clickHost=$click[host];
$clickURL=$click[path];
$click=parse_url($_SERVER["HTTP_REFERER"]);
$clickPage=$click[path];

$wpdb->query("insert into meng_tracker_clicks (longIP,IP, outbound, clickType,clickPage,clickDate,clickURL,clickHost) values ('$longIP','$ip','$outbound','$clickType','$clickPage',now(),'$clickURL','$clickHost')");
?>
